// src/lib/i18n/direction.ts
export const getTextDirection = (locale: string) => locale === 'ar' ? 'rtl' : 'ltr'
